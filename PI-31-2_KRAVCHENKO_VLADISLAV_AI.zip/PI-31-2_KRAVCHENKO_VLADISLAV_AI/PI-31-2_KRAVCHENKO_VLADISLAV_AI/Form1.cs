﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (clickedButton.BackColor == Color.Black)
                {
                    clickedButton.BackColor = Color.White;
                   
                }
                else
                {
                    clickedButton.BackColor = Color.Black;
                   
                }
            }
        }
    } 
} 