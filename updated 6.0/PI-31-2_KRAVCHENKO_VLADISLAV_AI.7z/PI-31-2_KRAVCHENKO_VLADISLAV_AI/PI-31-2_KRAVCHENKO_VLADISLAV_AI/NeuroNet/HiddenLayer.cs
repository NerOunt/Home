﻿
namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeuroNet
{
    class HiddenLayer:Layer
    {
        public HiddenLayer(int non,int nonp,NeuronType nt, string type):
            base(non, nonp, nt, type)
        { }
    }
}
