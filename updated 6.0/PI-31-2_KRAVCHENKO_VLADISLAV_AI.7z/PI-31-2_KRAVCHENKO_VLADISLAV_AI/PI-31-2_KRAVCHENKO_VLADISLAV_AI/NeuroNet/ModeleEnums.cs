﻿namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeuroNet
{
   enum MemoryMode
    {
        GET,
        SET,
        INIT
    }
    enum NeuronType
    {
        Hidden,
        Output
    }
    enum NetworkMode
    {
        Train,
        Test,
        Demo
    }
}

