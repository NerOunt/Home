﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeuroNet;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI
{
    public partial class FormMain : Form
    {
        HiddenLayer hiddenLayer; // это потом убрать (временная переменная)
        private double[] inputPixels;//массив входных данных

        //конструктор
        public FormMain()
        {
            InitializeComponent();
            inputPixels = new double[15];
        }
               
        private void Changing_State_Pixel_Button_Click(object sender, EventArgs e) 
        {
            if (((Button)sender).BackColor == Color.White)
            {
                ((Button)sender).BackColor = Color.Black;
                inputPixels[((Button)sender).TabIndex] = 1d;
            }
            else
            {
                ((Button)sender).BackColor = Color.White;
                inputPixels[((Button)sender).TabIndex] = 0d;
            }
        }
        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void SaveTrainSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "train.txt";
            string tmpStr = numericUpDown2.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++)
            {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += '\n'; 

            File.AppendAllText(path, tmpStr);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            hiddenLayer = new HiddenLayer(9, 7, NeuronType.Hidden, nameof(hiddenLayer));
            hiddenLayer.WeightInitialize(MemoryMode.SET, AppDomain.CurrentDomain.BaseDirectory + nameof(hiddenLayer) + "_memory.csv");
        }
    }
}