﻿using System;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeyroNet
{
    class DropoutLayer
    {
        private double dropoutRate;
        private Random random;
        private bool[] mask;
        private bool isTraining;

        public DropoutLayer(double rate = 0.5)
        {
            dropoutRate = rate;
            random = new Random(Guid.NewGuid().GetHashCode());
            isTraining = true;
        }

        public void SetTrainingMode(bool training)
        {
            isTraining = training;
        }

       
        public double[] Apply(double[] inputs)
        {
            if (!isTraining || dropoutRate <= 0.0)
                return inputs;

            int size = inputs.Length;
            mask = new bool[size];
            double[] outputs = new double[size];

            
            double scale = 1.0 / (1.0 - dropoutRate);

            for (int i = 0; i < size; i++)
            {
                if (random.NextDouble() > dropoutRate)
                {
                    mask[i] = true;
                    outputs[i] = inputs[i] * scale; 
                }
                else
                {
                    mask[i] = false;
                    outputs[i] = 0.0;
                }
            }

            return outputs;
        }

        
        public double[] ApplyToGradients(double[] gradients)
        {
            if (!isTraining || mask == null)
                return gradients;

            double[] result = new double[gradients.Length];
            double scale = 1.0 / (1.0 - dropoutRate);

            for (int i = 0; i < gradients.Length; i++)
            {
                result[i] = mask[i] ? gradients[i] * scale : 0.0;
            }

            return result;
        }
    }

    class HiddenLayer : Layer
    {

        public HiddenLayer(int non, int nonp, NeuronType nt, string type) :
            base(non, nonp, nt, type)
        { }

        public override void Recognize(Network net, Layer nextLayer)
        {
             double[] hidden_out = new double[numofneurons];
            for (int i = 0; i < numofneurons; i++)
                hidden_out[i] = neurons[i].Output;

            
            if (dropoutLayer != null)
            {
                hidden_out = dropoutLayer.Apply(hidden_out);                
            }

            nextLayer.Data = hidden_out;
        }

        
       
        public override double[] BackwardPass(double[] gr_sums)
        {
           
            if (dropoutLayer != null)
            {
                gr_sums = dropoutLayer.ApplyToGradients(gr_sums);
            }

            
            double[] gr_sum = new double[numofprevneurons];
            for (int j = 0; j < numofprevneurons; j++)
            {
                double sum = 0;
                for (int k = 0; k < numofneurons; k++)
                    sum += neurons[k].Weights[j + 1] * neurons[k].Derivative * gr_sums[k];
                gr_sum[j] = sum;
            }
            for (int i = 0; i < numofneurons; i++)
                for (int n = 0; n < numofprevneurons + 1; n++)
                {
                    double deltaw;
                    if (n == 0)
                        deltaw = momentum * lastdeltaweights[i, 0] + learningrate * neurons[i].Derivative * gr_sums[i];
                    else
                        deltaw = momentum * lastdeltaweights[i, n] + learningrate * neurons[i].Inputs[n - 1] * neurons[i].Derivative * gr_sums[i];
                    lastdeltaweights[i, n] = deltaw;
                    neurons[i].Weights[n] += deltaw;
                }
            return gr_sum;
        }


        private DropoutLayer dropoutLayer;

        public void AddDropout(double rate = 0.5)
        {
            dropoutLayer = new DropoutLayer(rate);
        }

        public void SetDropoutTraining(bool isTraining)
        {
            if (dropoutLayer != null)
                dropoutLayer.SetTrainingMode(isTraining);
        }

        
        public double[] GetOutputWithDropout(bool applyDropout = true)
        {
            double[] outputs = new double[numofneurons];
            for (int i = 0; i < numofneurons; i++)
                outputs[i] = neurons[i].Output;

            if (dropoutLayer != null && applyDropout)
                return dropoutLayer.Apply(outputs);
            else
                return outputs;
        }

        public double[] ApplyDropoutToGradients(double[] gradients)
        {
            if (dropoutLayer != null)
                return dropoutLayer.ApplyToGradients(gradients);
            else
                return gradients;
        }
    }
}