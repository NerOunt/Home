﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeyroNet;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI
{
    public partial class Form1 : Form
    {
        public double[] inputPixels;
        private Network network;

        public Form1()
        {
            InitializeComponent();

            inputPixels = new double[15];

            network = new Network();
            network.SetDropoutRates(0.1, 0.1);
            network.UseDropout = false;
        }

        private void Changing_State_Pixel_Button_Click(object sender, EventArgs e)
        {
            if (((Button)sender).BackColor == Color.White)
            {
                ((Button)sender).BackColor = Color.Black;
                inputPixels[((Button)sender).TabIndex] = 1d;
            }
            else
            {
                ((Button)sender).BackColor = Color.White;
                inputPixels[((Button)sender).TabIndex] = 0d;
            }
        }

        private void button_SaveTrainSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "train.txt";
            string tmpStr = numericUpDown_NecessaryOutput.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++)
            {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += '\n';

            File.AppendAllText(path, tmpStr);

        }

        /*private void button16_Click(object sender, EventArgs e)
        {
            hiddenlayer = new HiddenLayer(9, 7, NeuronType.Hidden, nameof(hiddenlayer));
            hiddenlayer.WeightInitialize(MemoryMode.SET, "test.csv");
        }*/

        private void buttonRecognize_Click(object sender, EventArgs e)
        {
            network.RecognizeDigit(inputPixels);
            int maxIndex = 0;
            for (int i = 1; i < network.Fact.Length; i++)
            {
                if (network.Fact[i] > network.Fact[maxIndex])
                    maxIndex = i;
            }

            labelOutput.Text = maxIndex.ToString();
            labelProbability.Text = (100 * network.Fact[maxIndex]).ToString("0.00") + " %";
        }

        private void buttonTraining_Click(object sender, EventArgs e)
        {
            bool originalUseDropout = network.UseDropout;

            try
            {
                network.Train(network);
                for (int i = 0; i < network.E_error_avr.Length; i++)
                    chart_Eavr.Series[0].Points.AddY(network.E_error_avr[i]);

                MessageBox.Show("Обучение успешно завершено!", "Информация",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                
                network.UseDropout = originalUseDropout;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chart_Eavr_Click(object sender, EventArgs e)
        {

        }

        private void buttonTest_Click(object sender, EventArgs e)
        {
            /* network.Test(network);
             for (int i = 0; i < network.E_error_avr.Length; i++)
                 chart_Eavr.Series[0].Points.AddY(network.E_error_avr[i]);

             MessageBox.Show("Тестирование успешно завершено!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            */
            bool originalUseDropout = network.UseDropout;

            try
            {
                network.Test(network);
                for (int i = 0; i < network.E_error_avr.Length; i++)
                    chart_Eavr.Series[0].Points.AddY(network.E_error_avr[i]);

                MessageBox.Show("Тестирование успешно завершено!", "Информация",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                network.UseDropout = originalUseDropout;
            }
        }
        
        

        private void button_SaveTestSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "test.txt";
            string tmpStr = numericUpDown_NecessaryOutput.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++)
            {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += '\n';

            File.AppendAllText(path, tmpStr);

        }

        private void Dropout_Click(object sender, EventArgs e)
        {
            network.UseDropout = !network.UseDropout;

            Button btn = (Button)sender;
            if (network.UseDropout)
            {
                btn.Text = "Выключить Dropout";
                btn.BackColor = Color.LightGreen;
            }
            else
            {
                btn.Text = "Включить Dropout";
                btn.BackColor = SystemColors.Control;
            }

            MessageBox.Show($"Dropout {(network.UseDropout ? "включен" : "выключен")}", "Информация",
                MessageBoxButtons.OK,   MessageBoxIcon.Information);
        }
    }

    
}
