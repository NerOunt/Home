﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeuroNet
{
    class HiddenLayer
    {
    }
}
