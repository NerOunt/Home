﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using PI_31_2_KRAVCHENKO_VLADISLAV_AI.NeyroNet;

namespace PI_31_2_KRAVCHENKO_VLADISLAV_AI
{
    public partial class Form1 : Form
    {
        public double[] inputPixels;
        private Network network;
        //HiddenLayer hiddenlayer;

        public Form1()
        {
            InitializeComponent();

            inputPixels = new double[15];

            network = new Network();
        }

        private void Changing_State_Pixel_Button_Click(object sender, EventArgs e)
        {
            if (((Button)sender).BackColor == Color.White)
            {
                ((Button)sender).BackColor = Color.Black;
                inputPixels[((Button)sender).TabIndex] = 1d;
            }
            else
            {
                ((Button)sender).BackColor = Color.White;
                inputPixels[((Button)sender).TabIndex] = 0d;
            }
        }

        private void button_SaveTrainSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "train.txt";
            string tmpStr = numericUpDown_NecessaryOutput.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++)
            {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += '\n';

            File.AppendAllText(path, tmpStr);

        }

        private void button_ClearField_Click(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button button && button.TabIndex >= 0 && button.TabIndex < inputPixels.Length)
                {
                    button.BackColor = Color.White;
                    inputPixels[button.TabIndex] = 0d;
                }
            }
        }

    

        /*private void button16_Click(object sender, EventArgs e)
        {
            hiddenlayer = new HiddenLayer(9, 7, NeuronType.Hidden, nameof(hiddenlayer));
            hiddenlayer.WeightInitialize(MemoryMode.SET, "test.csv");
        }*/

        private void buttonRecognize_Click(object sender, EventArgs e)
        {
            network.ForwardPass(network, inputPixels);
            labelOutput.Text = network.Fact.ToList().IndexOf(network.Fact.Max()).ToString();
            labelProbability.Text = (100 * network.Fact.Max()).ToString("0.00") + " %";
        }

        private void buttonTraining_Click(object sender, EventArgs e)
        {
            network.Train(network);
            for (int i = 0; i < network.E_error_avr.Length; i++)
                chart_Eavr.Series[0].Points.AddY(network.E_error_avr[i]);

            MessageBox.Show("Обучение успешно завершено!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void chart_Eavr_Click(object sender, EventArgs e)
        {

        }
    }

    // Архитектура: 15-71-33-10
}
